<footer class="main-footer">
        <!-- To the right -->
        <div class="pull-right hidden-xs">
          Soluciones en Informatica.
        </div>
        <!-- Default to the left -->
        <strong>Copyright &copy; 2017 Soluciones en Informatica | <a href=''></a></strong> | All rights reserved.
      </footer>
